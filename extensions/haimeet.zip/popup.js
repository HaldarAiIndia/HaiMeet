document.getElementById('openBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://HaiMeet.vercel.app' });
});
