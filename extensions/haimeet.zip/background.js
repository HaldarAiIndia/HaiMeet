chrome.action.onClicked.addListener(() => {
  chrome.windows.create({
    url: chrome.runtime.getURL('index.html'),
    state: 'fullscreen',
    type: 'popup'
  });
});
